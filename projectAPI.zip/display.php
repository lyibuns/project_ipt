<!DOCTYPE html>
<html>
<head>
    <title>Book Search Results</title>
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<?php
// Database Connection
$connection = mysqli_connect('localhost', 'root', '', 'university');

// Database Connection Check
if (!$connection) {
    die('Database connection failed: ' . mysqli_connect_error());
}

// Check if the form is submitted and update the "finish" value if necessary to avoid problems.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['book_id']) && isset($_POST['finish'])) {
        $bookId = $_POST['book_id'];
        $finishValue = $_POST['finish'];

        // Update the "finish" value in the database for the specified book_id
        $updateQuery = "UPDATE books SET finish = $finishValue WHERE book_id = '$bookId'"; // Wrap $bookId in quotes
        $updateResult = mysqli_query($connection, $updateQuery);

        // Check if the update was successful
        if (!$updateResult) {
            die('Update query failed: ' . mysqli_error($connection));
        }
    }
    
    if (isset($_POST['delete_book'])) {
        $bookId = $_POST['delete_book'];

        // Delete the book from the database
        $deleteQuery = "DELETE FROM books WHERE book_id = '$bookId'"; // Wrap $bookId in quotes
        $deleteResult = mysqli_query($connection, $deleteQuery);

        // Check if the deletion was successful
        if (!$deleteResult) {
            die('Delete query failed: ' . mysqli_error($connection));
        }
    }
}

// Retrieve all data from the 'books' table
$query = 'SELECT * FROM books';
$result = mysqli_query($connection, $query);

// Check if the query was successful
if (!$result) {
    die('Query execution failed: ' . mysqli_error($connection));
}

// Display the data in a table
echo '<table>';
echo '<tr><th>Title</th><th>Author</th><th>Publisher</th><th>Pages</th><th>Book ID</th><th>Finished</th><th>Action</th></tr>';

while ($row = mysqli_fetch_assoc($result)) {
    echo '<tr>';
    echo '<td>' . $row['title'] . '</td>';
    echo '<td>' . $row['author'] . '</td>';
    echo '<td>' . $row['publisher'] . '</td>';
    echo '<td>' . $row['pages'] . '</td>';
    echo '<td>' . $row['book_id'] . '</td>';
    echo '<td>' . $row['finish'] . '</td>';
    echo '<td>';
    echo '<form method="POST" action="display.php">';
    echo '<input type="hidden" name="book_id" value="' . $row['book_id'] . '">';
    echo '<input type="hidden" name="finish" value="' . ($row['finish'] == 0 ? 1 : 0) . '">';
    echo '<input type="submit" class="finish-button" value="' . ($row['finish'] == 0 ? 'Finish' : 'Unfinish') . '">';
    echo '</form>';
    echo '</td>';
    echo '<td>';
    echo '<form method="POST" action="display.php">';
    echo '<input type="hidden" name="delete_book" value="' . $row['book_id'] . '">';
    echo '<button type="submit" class="delete-button">Delete</button>';
    echo '</form>';
    echo '</td>';
    echo '</tr>';
}
echo '</table>';

// Close the database connection
mysqli_close($connection);
?>
<div style="text-align: center; margin-top: 20px;">
    <a href="main.php" class="button">Go Back</a>
</body>
</html>