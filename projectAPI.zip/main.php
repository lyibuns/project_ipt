<html>
<head>
	<title>Book Search</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="container">
  <form action="search.php" method="post">
    <label for="search_query">Search:</label>
    <input type="text" name="search_query" id="search_query" placeholder="Input Keywords">
    <input type="submit" value="Submit" class="gradient-button">
  </form>
  <form action="display.php" method="post">
    <input type="submit" value="Show Book Database" class="gradient-button">
  </form>
</div>
</body>
</html>
