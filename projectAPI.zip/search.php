<!DOCTYPE html>
<html>
<head>
    <title>Book Search Results</title>
    <link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<?php

// Get user input from form
$search_query = $_POST['search_query'];

// Construct API request URL with API key
$api_key = 'AIzaSyCig4kEdRfxizPv-k69zaLid9JcJ8aiepg';
$api_url = "https://www.googleapis.com/books/v1/volumes?q=" . urlencode($search_query) . "&key=" . $api_key;

// Send API request and get response
$response = file_get_contents($api_url);

// Check if API request was successful
if ($response === false) {
    echo "Failed to fetch data from the API.";
    exit;
}

// Decode JSON response
$books_data = json_decode($response, true);

// Check if any books were found
if (!isset($books_data['items'])) {
    echo "No books found for the given query.";
    exit;
}

// Extract book details from response
$books = $books_data['items'];

// Check if any books were found
if (empty($books)) {
    echo "No books found for the given query.";
    exit;
}

// Save book details to database
$conn = mysqli_connect("localhost", "root", "", "university");
if (!$conn) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit;
}

// Create an HTML table to display the book details
echo '<table>';
echo '<tr>';
echo '<th>Book ID</th>';
echo '<th>Title</th>';
echo '<th>Author</th>';
echo '<th>Publisher</th>';
echo '<th>Pages</th>';
echo '</tr>';

// Iterate over each book and save its details to the database and display in the table
foreach ($books as $book) {
    $book_id = mysqli_real_escape_string($conn, $book['id']);
    $title = mysqli_real_escape_string($conn, $book['volumeInfo']['title']);
    
    // Check if author data exists
    if (isset($book['volumeInfo']['authors'])) {
        $author = mysqli_real_escape_string($conn, $book['volumeInfo']['authors'][0]);
    } else {
        $author = "Unknown";
    }
    
    // Check if publisher data exists
    if (isset($book['volumeInfo']['publisher'])) {
        $publisher = mysqli_real_escape_string($conn, $book['volumeInfo']['publisher']);
    } else {
        $publisher = "Unknown";
    }
    
    // Check if number of pages data exists
    if (isset($book['volumeInfo']['pageCount'])) {
        $pages = $book['volumeInfo']['pageCount'];
    } else {
        $pages = "Unknown";
    }
    
    // Initialize the $finish variable
$finish = 0;

// Check if the book already exists in the database
$sql = "SELECT * FROM books WHERE book_id = '$book_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // Book already exists in the database, fetch the 'finish' value
    $row = mysqli_fetch_assoc($result);
    $finish = $row['finish'];
} else {
    // Book does not exist in the database, insert it
    $sql = "INSERT INTO books (book_id, title, author, publisher, pages, finish) VALUES ('$book_id', '$title', '$author', '$publisher', '$pages', '0')";
    if (mysqli_query($conn, $sql)) {
        // Book details saved to the database
    } else {
        echo "Error: " . mysqli_error($conn) . "<br>";
    }
}   
    // Display book details in the table
    echo '<tr>';
    echo '<td>' . $book_id . '</td>';
    echo '<td>' . $title . '</td>';
    echo '<td>' . $author . '</td>';
    echo '<td>' . $publisher . '</td>';
    echo '<td>' . $pages . '</td>';
    echo '</tr>';
}

echo '</table>';

mysqli_close($conn);
?>

<div style="text-align: center; margin-top: 20px;">
    <a href="main.php" class="button">Go Back</a>
</body>
</html>