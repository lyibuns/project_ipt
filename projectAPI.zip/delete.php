<?php
// Establish a database connection
$conn = mysqli_connect("localhost", "root", "", "university");
if (!$conn) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit;
}

// Get the book ID from the URL parameter
$id = $_GET['id'];

// Perform the delete operation
$sql = "DELETE FROM books WHERE book_id = '$id'";
if (mysqli_query($conn, $sql)) {
    echo "Book deleted successfully.";
} else {
    echo "Error deleting book: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
