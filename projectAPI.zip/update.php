<?php
// Get the book ID and finish value from the form submission
$book_id = $_POST['book_id'];
$finish = $_POST['finish'];

// Validate and sanitize the input if needed

// Update the 'finish' value in the database
$conn = mysqli_connect("localhost", "root", "", "university");
if (!$conn) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit;
}

$sql = "UPDATE books SET finish = '$finish' WHERE book_id = '$book_id'";
if (mysqli_query($conn, $sql)) {
    echo "The 'finish' value has been updated successfully.";
} else {
    echo "Error updating 'finish' value: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
